#define ZINT
#include "umf_get_memory.c"
