#define DLONG

#include "amd_order.c"
