#define DINT
#include "umf_analyze.c"
