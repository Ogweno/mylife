#define DLONG

#include "umf_scale_column.c"
