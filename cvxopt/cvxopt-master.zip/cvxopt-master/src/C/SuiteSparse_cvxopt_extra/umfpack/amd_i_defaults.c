#define DINT

#include "amd_defaults.c"
