#define DINT

#include "amd_dump.c"
