#define DINT

#include "amd_postorder.c"
