#define ZLONG
#include "umfpack_symbolic.c"
