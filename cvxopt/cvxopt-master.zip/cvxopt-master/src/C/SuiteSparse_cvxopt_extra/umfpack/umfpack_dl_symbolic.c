#define DLONG
#include "umfpack_symbolic.c"
