#define ZLONG

#include "umfpack_solve.c"
