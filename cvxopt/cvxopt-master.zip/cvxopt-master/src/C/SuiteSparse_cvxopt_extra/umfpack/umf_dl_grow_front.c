#define DLONG

#include "umf_grow_front.c"
