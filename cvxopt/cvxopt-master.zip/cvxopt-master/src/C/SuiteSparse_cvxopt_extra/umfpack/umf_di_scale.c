#define DINT
#include "umf_scale.c"
