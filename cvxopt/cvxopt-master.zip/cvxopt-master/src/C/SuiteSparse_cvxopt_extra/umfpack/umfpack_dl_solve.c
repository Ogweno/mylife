#define DLONG

#include "umfpack_solve.c"
