#define ZLONG

#include "umf_kernel_init.c"
