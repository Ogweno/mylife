#define DLONG

#include "umf_malloc.c"
